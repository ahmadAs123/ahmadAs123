#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include "threadpool.h"
#define RFC1123FMT "%a, %d %b %Y %H:%M:%S GMT"
char first_element[1000];// GET ARRAY
int newfd;
int counter_spaces;// for how tokens
int counter=0;// to first element
struct stat r;
struct stat r1;
char second_elemnt[1000];//PATH ARRAY
char third_elemnt[1000];//PROTOCOL ARRAY
int calc_size(){
    time_t a ;
    char sec1[10000]="";
    strcat(sec1,".");
    strcat(sec1,second_elemnt);
    //   printf("%s",sec1);
    char t_path[1000]="";
    struct stat f;
    stat(sec1, &f);
    char final[66];
    char final1[66];
    char final2[66];
    struct tm *total ;
    a=time( NULL);
    strftime(final, sizeof(final), RFC1123FMT, gmtime(&a));// for time
    strftime(final1, sizeof(final1) ,RFC1123FMT, gmtime(&f.st_mtime));// for last modefied
    char error[15000]="";
    strcat(error,"<HTML>\r\n");
    strcat(error,"<HEAD><TITLE>Index of ");
    strcat(error,sec1);
    strcat(error,"</TITLE></HEAD>\r\n\r\n");
    strcat(error,"<BODY>\r\n");
    strcat(error,"<H4>Index of ");
    strcat(error,sec1);
    strcat(error,"</H4>\r\n\r\n");
    strcat(error,"<table CELLSPACING=8>\r\n");
    strcat(error,"<tr><th>Name</th><th>Last Modified</th><th>Size</th></tr>\r\n\r\n\r\n");
    //   sec1[strlen(second_elemnt)+2]='\0';
    DIR *temp_directory = opendir(sec1);
    if (temp_directory == NULL) {
        char r[50]="";
        write(newfd, r, strlen((r)));
        close(newfd);
    }
    struct dirent *curr_file;
    // raead the first file
    while (curr_file = readdir(temp_directory)){// loop on all the files in dir
        strcat(error,"<tr>\r\n");
        strcat(error, "<td><A HREF=\"");
        strcat(error,curr_file->d_name);
        strcat(error,"\">");
        strcat(error,curr_file->d_name);
        // strcat(error,"<");
        strcat(error,"</A></td>\r\n");
        strcat(error,"<td>");
        strcat(t_path,sec1);
        strcat(t_path,curr_file->d_name);
        t_path[strlen(t_path)+2]='\0';
        stat(t_path, &f);
        strftime(final2, sizeof(final2) ,RFC1123FMT, gmtime(&f.st_mtime));
        strcat(error,final2);
        strcat(error,"</td>\r\n");
        stat(t_path, &r1);
        if(S_ISDIR(r1.st_mode)) {
            strcat(error,"</tr>\r\n");
        }
        else{
            char t[100];
            off_t size=r1.st_size;
            sprintf(t, "%lu", size);
            strcat(error,"<td>");
            strcat(error, t);
            strcat(error,"</td>\r\n");

        }
        strcpy(t_path,"");
        //  curr_file = readdir(temp_directory);
    }
//closedir(temp_directory);
    strcat(error,"</tr>\r\n");
    strcat(error,  "</table>\r\n");
    strcat(error,  "<HR>\r\n");
    strcat(error, "<ADDRESS>webserver/1.0</ADDRESS>\r\n");
    strcat(error, "</BODY></HTML>");
  int res =strlen(error);
  strcpy(error,"");
return res;
}








void dir_cont(){// to print the files in directory
    time_t a ;
    char sec1[10000]="";
    strcat(sec1,".");
    strcat(sec1,second_elemnt);
 //   printf("%s",sec1);
    char t_path[1000]="";
    struct stat f;
    stat(sec1, &f);
    char final[66];
    char result[10];
    char final1[66];
    char final2[66];
    struct tm *total ;
    a=time( NULL);
    strftime(final, sizeof(final), RFC1123FMT, gmtime(&a));// for time
    strftime(final1, sizeof(final1) ,RFC1123FMT, gmtime(&f.st_mtime));// for last modefied
    char error[15000]="";
    strcat(error,"HTTP/1.1 200 OK\r\n");
    strcat(error,"Server: webserver/1.0\r\n");
    strcat(error,"Date: ");
    strcat(error,final);
    strcat(error, "\r\n");
    strcat(error,"Content-Type: text/html\r\n");
    strcat(error,"Content-Length: ");
    int y=calc_size();
    sprintf(result,"%d",y);
    strcat(error, result);
    strcat(error, "\r\n");// i muat count the suze here
    strcat(error,"Last-Modified: ");
    strcat(error,final1);
    strcat(error, "\r\n");
    strcat(error,"Connection: close\r\n\r\n");
    strcat(error,"<HTML>\r\n");
    strcat(error,"<HEAD><TITLE>Index of ");
    strcat(error,sec1);
    strcat(error,"</TITLE></HEAD>\r\n\r\n");
    strcat(error,"<BODY>\r\n");
    strcat(error,"<H4>Index of ");
    strcat(error,sec1);
    strcat(error,"</H4>\r\n\r\n");
    strcat(error,"<table CELLSPACING=8>\r\n");
    strcat(error,"<tr><th>Name</th><th>Last Modified</th><th>Size</th></tr>\r\n\r\n\r\n");
 //   sec1[strlen(second_elemnt)+2]='\0';
    DIR *temp_directory = opendir(sec1);
    if (temp_directory == NULL) {
        char r[50]="";
                write(newfd, r, strlen((r)));
        close(newfd);
    }
    struct dirent *curr_file;
   // raead the first file
    while (curr_file = readdir(temp_directory)){// loop on all the files in dir
        strcat(error,"<tr>\r\n");
        strcat(error, "<td><A HREF=\"");
        strcat(error,curr_file->d_name);
        strcat(error,"\">");
        strcat(error,curr_file->d_name);
       // strcat(error,"<");
        strcat(error,"</A></td>\r\n");
        strcat(error,"<td>");
        strcat(t_path,sec1);
        strcat(t_path,curr_file->d_name);
        t_path[strlen(t_path)+2]='\0';
        stat(t_path, &f);
        strftime(final2, sizeof(final2) ,RFC1123FMT, gmtime(&f.st_mtime));
        strcat(error,final2);
        strcat(error,"</td>\r\n");
        stat(t_path, &r1);
        if(S_ISDIR(r1.st_mode)) {
            strcat(error,"</tr>\r\n");
        }
        else{
            char t[100];
            off_t size=r1.st_size;
            sprintf(t, "%lu", size);
            strcat(error,"<td>");
            strcat(error, t);
            strcat(error,"</td>\r\n");

        }
        strcpy(t_path,"");
    //  curr_file = readdir(temp_directory);
    }
//closedir(temp_directory);
    strcat(error,"</tr>\r\n");
    strcat(error,  "</table>\r\n");
    strcat(error,  "<HR>\r\n");
    strcat(error, "<ADDRESS>webserver/1.0</ADDRESS>\r\n");
    strcat(error, "</BODY></HTML>");

    write(newfd, error, strlen(error));
    close(newfd);
}






void page501(){

     time_t a ;
    char final[1000];
    struct tm *total ;
    a=time( NULL);
    strftime(final, sizeof(final),RFC1123FMT,gmtime(&a));
    char error[10000];
    strcat(error,"HTTP/1.1 501 Not supported\r\n");
    strcat(error,"Server: webserver/1.0\r\n");
    strcat(error,"Date: ");
    strcat(error,final);
    strcat(error,"Content-Type: text/html\r\n");
    strcat(error,"Content-Length: ");
    strcat(error, "129\r\n");
    strcat(error,"Connection: close\r\n\r\n");
    strcat(error, "<HTML><HEAD><TITLE>501 Not supported</TITLE></HEAD>\r\n"
                  "<BODY><H4>501 Not supported</H4>\r\n"
                  "Method is not supported.\r\n"
                  "</BODY></HTML>");

    write(newfd, error, strlen((error)));
    close(newfd);}





void page404(){

    time_t a ;
    char final[1000];
    struct tm *total ;
    a=time( NULL);
    strftime(final, sizeof(final),RFC1123FMT,gmtime(&a));
    char error[15000];
    strcat(error,"HTTP/1.1 404 Not Found\r\n");
    strcat(error,"Server: webserver/1.0\r\n");
    strcat(error,"Date: ");
    strcat(error,final);
    strcat(error,"Content-Type: text/html\r\n");
    strcat(error,"Content-Length: ");
    strcat(error, "112\r\n\r\n");
    strcat(error, "<HTML><HEAD><TITLE>404 Not Found</TITLE></HEAD>\r\n"
                  "<BODY><H4>404 Not Found</H4>\r\n"
                  "File not found.\r\n"
                  "</BODY></HTML>");
    write(newfd, error, strlen((error)));
    close(newfd);
}




void page302(char arr[]){

   time_t a ;
    char final[1000];
    struct tm *total ;
    a=time( NULL);
    strftime(final, sizeof(final),RFC1123FMT,gmtime(&a));
    char error[10000];
    strcat(error,"HTTP/1.0 302 Found\r\n");
    strcat(error,"Server: webserver/1.0\r\n");
    strcat(error,"Date: ");
    strcat(error,final);
    strcat(error,"\r\n");
    strcat(error,"Location: ");
    strcat(error,arr);
    strcat(error,"/\r\n");
    strcat(error,"Content-Type: text/html\r\n");
    strcat(error,"Content-Length: ");
    strcat(error, "123\r\n");
    strcat(error,"Connection: close\r\n\r\n");
    strcat(error, "<HTML><HEAD><TITLE>302 Found</TITLE></HEAD>\r\n<BODY><H4>302 Found</H4>\r\nDirectories must end with a slash.\r\n</BODY></HTML>");
    write(newfd, error, strlen((error)));
    close(newfd);





}

void page403(){

    time_t a ;
    char final[1000];
    struct tm *total ;
    a=time( NULL);
    strftime(final, sizeof(final),RFC1123FMT,gmtime(&a));
    char error[10000];
    strcat(error,"HTTP/1.1 403 Forbidden\r\n");
    strcat(error,"Server: webserver/1.0\r\n");
    strcat(error,"Date: ");
    strcat(error,final);
    strcat(error,"\r\n");
    strcat(error,"Content-Type: text/html\r\n");
    strcat(error,"Content-Length: ");
    strcat(error, "111\r\n");
    strcat(error,"Connection: close\r\n\r\n");
    strcat(error, "<HTML><HEAD><TITLE>403 Forbidden</TITLE></HEAD>\r\n"
                  "<BODY><H4>403 Forbidden</H4>\r\n"
                  "Access denied.\r\n"
                  "</BODY></HTML>");

    write(newfd, error, strlen((error)));
    close(newfd);
}




void page400() {

    char numm[10];
    char t[10];
    char p[10];
    sprintf(numm, "%d", counter);
    sprintf(t, "%d", counter_spaces);
    time_t a;
    char final[1000];
    struct tm *total;
    a = time(NULL);
    total = localtime(&a);
    strftime(final, sizeof(final), RFC1123FMT, gmtime(&a));
    char error[10000];
    strcat(error, p);
    strcat(error, "\r\n");
    strcat(error, "HTTP/1.1 400 Bad Request\r\n");
    strcat(error, "Server: webserver/1.0\r\n");
    strcat(error, "Date: ");
    strcat(error, final);
    strcat(error, "\r\n");
    strcat(error, "Content-Type: text/html\r\n");
    strcat(error, "Content-Length: ");
    strcat(error, "113\r\n");
    strcat(error, "Connection: close\r\n\r\n");
    strcat(error, "<HTML><HEAD><TITLE>400 Bad Request</TITLE></HEAD>\r\n"
                  "<BODY><H4>400 Bad request</H4>\r\n"
                  "Bad Request.\r\n"
                  "</BODY></HTML>");

    write(newfd, error, strlen((error)));
    close(newfd);

}



char *get_mime_type(char *name)
{
    char *ext = strrchr(name, '.');
    if (!ext) return NULL;
    if (strcmp(ext, ".html") == 0 || strcmp(ext, ".htm") == 0) return "text/html";
    if (strcmp(ext, ".jpg") == 0 || strcmp(ext, ".jpeg") == 0) return "image/jpeg";
    if (strcmp(ext, ".gif") == 0) return "image/gif";
    if (strcmp(ext, ".png") == 0) return "image/png";
    if (strcmp(ext, ".css") == 0) return "text/css";
    if (strcmp(ext, ".au") == 0) return "audio/basic";
    if (strcmp(ext, ".wav") == 0) return "audio/wav";
    if (strcmp(ext, ".avi") == 0) return "video/x-msvideo";
    if (strcmp(ext, ".mpeg") == 0 || strcmp(ext, ".mpg") == 0) return "video/mpeg";
    if (strcmp(ext, ".mp3") == 0) return "audio/mpeg";
    return NULL;
}

int size_file(char * n){
    long counter=0;
    FILE *fq = fopen(n, "r");// open for reading
    if (fq == NULL) {// the openung didnt success
        page404();
    }
    unsigned char fi[10000];
    while (!feof(fq)) {// rad the file
        fgets(fi, 10000, fq);
       counter+=strlen(fi);
    }
    return counter;
}



void file(int  k,char *n){
    struct stat f;
    stat(n, &f);
    char numm[10];
    char secc [10000];
    secc[0]='0';
    strcat(secc,second_elemnt);
    char t[10];
    char p[10];
    sprintf(numm, "%d", counter);
    sprintf(t, "%d", counter_spaces);
    time_t a ;
    char final[1000];
    char final1[1000];
    char * sizeo[1000];
    struct tm *total ;
    a=time( NULL);
    total = localtime( &a );
    strftime(final, sizeof(final),RFC1123FMT,gmtime(&a));
    strftime(final1, sizeof(final1) ,RFC1123FMT, gmtime(&f.st_mtime));
  char error[10000];
    strcat(error,"HTTP/1.1 200 OK\r\n");
    strcat(error,"Server: webserver/1.0\r\n");
    strcat(error,"Date: ");
    strcat(error,final);
    strcat(error,"\r\n");
    strcat(error,"Content-Type: ");
    strcat(error, get_mime_type(n));
    strcat(error, "\r\n");
    //<----------------------------------
    strcat(error,"Content-Length: ");
    sprintf(sizeo,"%d", k);
    strcat(error, sizeo);
    strcat(error, "\r\n");
    strcat(error,"Last-Modified: ");
    strcat(error,final1);
    strcat(error, "\r\n");
    strcat(error,"Connection: close\r\n\r\n");
    write(newfd, error, strlen((error)));
    int fq = open(n, O_RDONLY);// open for reading
    if (fq == NULL) {// the openung didnt success
      page404();
        return;
    }
    unsigned char fi[k];
  // read the file
        read(fq, fi, k);
        write(newfd, fi, k);


    close(newfd);

}



void working (int s){
    int counter1=0;// to second element
    int counter2=0;// to third elemnt
char req[10000];
char final[10000];
char*res;
int row;
counter1=0;
counter2=0;
counter_spaces=0;
counter=0;
    if(row = read(s, req, 10000) < 0) {// read the request from the socket into req array
        perror("Read Error");
        exit(1);
    }

 for(int i=0;i<strlen(req);i++){// take only the first line of hte request
     if(req[i]=='\r'){
         if(req[i+1]=='\n'){
             strncpy(final,req,i);
             break;
         }
     }
 }
if(strcmp(final,"")==0)// the final is empty there is no \r\n  (fa7s zaeed )
{
    perror("Read Error");
    exit(1);
}


counter_spaces=0;
for(int h=0;h< strlen(final);h++){// ----------------------------------------------------// CHECK IF THERE IS 3 TOKENS ONLY ACCORDING TO SPACES IN THE REQUEST

        if(final[h]==' ')
            counter_spaces++;

    }

    if(counter_spaces!=2){
        page400();
        return;
    }


for(int h=0;h< strlen(final);h++){// ------------------------------------------------- save first elenmt in requsest and check if first elemnt is GET

    if(final[h]!=' ')
        counter++;
    else
        break;
}
    // we find the GET
        strncpy(first_element,final,counter);
      first_element[counter]='\0';


    if (strcmp(first_element,"GET")!=0){
        page501();
    }





//--------------------------------------------------------------------------------------------------------save second elemnt in request and check
if(final[counter+1]!='/'){
  page404();
return;
}
    counter1=0;
    for(int h=counter+1;h< strlen(final);h++){ // save SECOND elenmt in requsest and check if first elemnt is GET

        if(final[h]!=' ')
            counter1++;
        else
            break;
    }

    if(counter1!=0){// we find the path
        strncpy(second_elemnt,final+4,counter1);
        second_elemnt[counter1]='\0';}



//------------------------------------------------------------------------------
    counter2=0;
    for(int h=counter1+2+counter;h< strlen(final);h++){ // save third elenmt in requsest and check if first elemnt is GET

        if(final[h]!='\0')
            counter2++;
        else
            break;
    }



    if(counter2!=0){// we find the protocol
        strncpy(third_elemnt,final+5+counter1,counter2);
        third_elemnt[counter2]='\0';}


    if(strcmp(third_elemnt,"HTTP/1.0")!=0&&strcmp(third_elemnt,"HTTP/1.1")!=0){//CHECK THE PROTOCOL
        page404();
        return;
    }

//--------------------------------------------------------------------------check if the path s true after that if is directory or file
    char sec[1000];
    sec[0]='.';
    strcat(sec,second_elemnt);
    if(stat(sec, &r)==0) {
        if (S_ISDIR(r.st_mode)!=0) {//the path is directory
            // printf("%s",second_elemnt);
            if (sec[strlen(sec) - 1] != '/') {//there is no / in the last of the path
                page302(second_elemnt);
                return;
            } else {

                DIR *tmp = opendir(sec);// opinig directory
                if (tmp == NULL) {
                    page400();
                    return;//--------> i dont know if that true check it later!!!!
                }

                struct dirent *c_file;
                char file[1000];
                c_file = readdir(tmp);// read the first file and point on it
                while (c_file != NULL) {// loop to take all the files and paths in directory
                    if (strcmp("index.html", c_file->d_name) == 0) {// we find the index.html
                        strcat(file, sec);
                        strcat(file, c_file->d_name);
                        char fi[10000];
                        FILE *f = fopen(file, "r");// open for reading
                        if (f == NULL) {// the openung didnt success
                           page404();
                            return;
                        }
                        while (!feof(f)) {// rad the file
                            fgets(fi, 10000, f);
                            write(newfd, fi, strlen(fi));
                        }
                        fclose(f);
                        close(newfd);
                        return;// i must complete it
                    }

                    c_file = readdir(tmp);
                }
                dir_cont();// we didnt find the index file then retuen all files in directory

            }

        }




//--------------------------------------------------------------------------- check if that path was a file

        else if (S_ISREG(r.st_mode)!=0) {// if file is readble for user and the others
            if ((r.st_mode & S_IROTH)) {// if the file is readble to others
           file(r.st_size,sec);// read it
           return;
        }
            else
                page403();
        }

            //----------------------------------------------------------------------------the path not file or directory

    }
       //------    ----------------------------------------------------------------------------------------------------------------check protocol HTTP
page404();

}

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
int main(int argc ,char**argv) {
    int fd;
    struct sockaddr_in clinet;
    int client_len = sizeof(clinet);
    if (argc>4||argc<4){// there is 3 tokens only
    printf("Usage: server <port> <pool-size>\n");
      exit(0);

}
    for(int i=0;i<strlen(argv[1]);i++)// checking the input is numbers only
    {
        if(argv[1][i]<'0'||argv[1][i]>'9')
        {
            printf("Usage: server <port> <pool-size>\n");
            exit(0);
        }
    }

    for(int j=0;j<strlen(argv[2]);j++)// check if the second erg is number
    {
        if(argv[2][j]<'0'||argv[2][j]>'9')
        {
            printf("Usage: server <port> <pool-size>\n");
            exit(0);
        }
    }


    for(int k=0;k<strlen(argv[3]);k++)// check if the third erg is number
    {
        if(argv[3][k]<'0'||argv[3][k]>'9')
        {
            printf("Usage: server <port> <pool-size>\n");
            exit(0);
        }
    }

    if(atoi(argv[1])<0||atoi(argv[2])<0||atoi(argv[3])<0) // check if the one of parmeters is under 0 (negative)
    {
        printf("Usage: server <port> <pool-size>\n");
        exit(0);
    }


if(atoi(argv[2])>MAXT_IN_POOL){// we cant make bigger than the mask
    printf("Usage: server <port> <pool-size>\n");
    exit(0);
}

  threadpool *ser_pool = create_threadpool(atoi(argv[2]));
   if(ser_pool==NULL){// we didnt success nmaking threadpol
       printf("Usage: server <port> <pool-size>");
       exit(0);
   }
    fd = socket(PF_INET, SOCK_STREAM, 0);
    if(fd < 0) {
        perror("<sys_call>");
        exit(1);
    }
    struct sockaddr_in srv;
    srv.sin_family = AF_INET;
    srv.sin_port = htons(atoi(argv[1]));
    srv.sin_addr.s_addr = htonl(INADDR_ANY);

    if(bind(fd, (struct sockaddr*) &srv, sizeof(srv)) < 0) {// binding
        perror("<sys_call>"); exit(1);
    }

    if(listen(fd, 5) < 0) {// we listwen
        perror("<sys_call>");
        exit(1);
    }


    for(int i=0;i<atoi(argv[3]);i++) {// here we are doing accept
        newfd = accept(fd, (struct sockaddr *) &clinet, &client_len);
        if (newfd < 0) {// didnt success
            perror("<sys_call>");
            exit(1);
        }
        dispatch(ser_pool,(dispatch_fn)working,(void*)newfd);// dispatching and work with thread with the args
    }
    destroy_threadpool(ser_pool);// destroying the threadpool
    close(fd);// closeing


}
//------------------------------------------------------------------------------



