#include <malloc.h>
#include "threadpool.h"
#include <pthread.h>
threadpool* create_threadpool(int num_threads_in_pool){
    if (num_threads_in_pool>MAXT_IN_POOL) // the size is bigger than the max
        return NULL;

    threadpool * thread_p=(threadpool*)malloc(sizeof(threadpool)); // creating the threadpool and intilizing
    if(thread_p==NULL)// the malloc didnt success
        return NULL;

    thread_p->qtail=NULL;
    thread_p->qhead=NULL;
    thread_p->num_threads=num_threads_in_pool;
    thread_p->shutdown=0;
    thread_p->dont_accept=0;
    thread_p->qsize=0;
    thread_p->threads=(pthread_t*)malloc(num_threads_in_pool*sizeof(pthread_t));
    if(thread_p->threads==NULL) // malloc faild
        return NULL;

    int res= pthread_cond_init(&thread_p->q_not_empty,NULL);// intilizing the not empty
    if(res!=0){
        return NULL;
    }
    int res1= pthread_cond_init(&thread_p->q_empty,NULL); // intilizing the empty
    if(res1!=0)
    {
        return NULL;
    }
    int res3= pthread_mutex_init(&thread_p->qlock,NULL); //intilizing the lock
    if(res3!=0)
    {
        return NULL;
    }
    for(int j=0;j<num_threads_in_pool;j++){//creating the threads and intilizing the do work
  pthread_create(&(thread_p->threads[j]),NULL,do_work,thread_p);
    }
    return thread_p;//checking the number of threads requested
}
//------------------------------------------------------------------------------------------------

void dispatch(threadpool* from_me, dispatch_fn dispatch_to_here, void *arg){
    if(from_me==NULL)
        return ;

    if(dispatch_to_here==NULL)
        return;

    if(from_me->dont_accept==1)// we cant insert while destroy
        return;

    work_t *w=(work_t*)malloc(sizeof(work_t));// creating the wrok and intilizing it
    if(w==NULL)// malloc   faild!
        return;
    w->next=NULL;
    w->arg=arg;
    w->routine=dispatch_to_here;

    pthread_mutex_lock(&from_me->qlock);// closing the lock

    if(from_me->qsize==0){//  queue is empty  make the work to be in head also the tail
        from_me->qhead=w;
        from_me->qtail=w;
        pthread_cond_signal(&from_me->q_not_empty);//signal that the queue is not empty yet
        from_me->qsize+=1;// the size is pluse 1
    }
    else{//  work last of the queue
        from_me->qtail->next=w;
        from_me->qtail=from_me->qtail->next;
        pthread_cond_signal(&from_me->q_not_empty);//signal that the queue is not em0pty yet
        from_me->qsize+=1;// the size is pluse 1
    }
    pthread_mutex_unlock(&from_me->qlock);// unlocking the lock
}
//---------------------------------------------------------------------------------------------------------

void* do_work(void* p){

   threadpool *th_p = (threadpool*)p;// creat threadpool
    while (1)
    {
        pthread_mutex_lock(&(th_p->qlock));
        if(th_p->shutdown==1)
        {
            pthread_mutex_unlock(&(th_p->qlock));
        return NULL;
        }


         if (th_p->qsize==0)// the queue empty
        {
            pthread_cond_wait(&(th_p->q_not_empty),&(th_p->qlock));


        }

        if (th_p->shutdown==1)
        {
            pthread_mutex_unlock(&(th_p->qlock));
            return NULL;
        }

        work_t *on = th_p->qhead;
        th_p->qsize-=1;
        if (th_p->qsize==0)// the queue empty
        {
            th_p->qtail = NULL;
            th_p->qhead = NULL;
            if(th_p->qsize==0&&th_p->dont_accept==1)// start the distructor destroy
            pthread_cond_signal(&(th_p->q_empty));
            pthread_mutex_unlock(&(th_p->qlock));
            on->routine(on->arg);
        }

        else {
            th_p->qhead = th_p->qhead->next;
            pthread_mutex_unlock(&(th_p->qlock));
            on->routine(on->arg);

        }

    }

}
//+-----------------------------------------------------------------------------------------------------

void destroy_threadpool(threadpool* destroyme){
    void *main_th;
   pthread_mutex_lock(&(destroyme->qlock));
   destroyme->dont_accept = 1;
   if(destroyme->qsize>0)
        pthread_cond_wait(&(destroyme->q_empty),&(destroyme->qlock));
    destroyme->shutdown = 1;
    for (int i=0;i<destroyme->num_threads;i++)// signal to all threads
    pthread_cond_signal(&(destroyme->q_not_empty));
   pthread_mutex_unlock(&(destroyme->qlock));
    for (int i = 0; i < destroyme->num_threads; i++)// join all the threads
        pthread_join(destroyme->threads[i], &main_th);
    free(destroyme);
}


