#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>


//id: 322786757
char**argv;
int wordcounterf(char a[]){
    int i=0;
    int wordcounter1=0;
    while (a[i] != '\0')      //while we don't finish the string
    {



        if (a[i] != ' ' && a[i + 1] == '\0') //it is a word
        {
            wordcounter1++;
            break;
        }

        if (a[i] != ' ' && a[i + 1] == ' ') // it is also a word
        {
            wordcounter1++;
            i++;
        }

        i++;
    }
    return wordcounter1;
}



int lettercounterf( char a[]) {
    int i = 0;
    int lettercounter1 = 0;

    while (a[i] != '\0')      //while we don't finish the string
    {
        if (a[i]!=' '&& a[i]!='\0')
            lettercounter1++;
        i++;
    }
    return  lettercounter1;
}







void find_words_and_save( char a[]){

    int j=0;
    int k=0;
    int count=0;

    char res[512];


    argv= (char**)malloc((wordcounterf(a)+1)*sizeof(char*));

    while(a[j]!='\0'){

        if(a[j]!=' '){

            j++;
        }


        if(a[j]==' ')  {

            strncpy(res,&a[count],j-count);
            res[j-count] = '\0';



                argv[k] = (char*)malloc((lettercounterf(res)+1)*sizeof(char));
                strcpy(argv[k],res);
                k++;


           while(a[j]==' '){

                j++;
            }
            count=j;
        }

    }
    strncpy(res,&a[count],j-count);
    res[j-count] = '\0';
    argv[wordcounterf(a)-1] = (char*)malloc((lettercounterf(res)+1)*sizeof(char));
    strcpy(argv[wordcounterf(a)-1],res);
    argv[wordcounterf(a)] = NULL;



}







int main() {
    int current =1;
    char num_line[10];
    char command[512];
    pid_t pid;
    char a[512];
    char str[512];
    FILE *fp;
    int i = 0;

    int commandscounter=0; //count the words
    int wordcounter=0;//count the letters




    while (1) {  // loop

        char cwd[200];
        if (getcwd(cwd, sizeof(cwd)) != NULL) {
            printf("%s->", cwd);
        }

        else {
            perror("getcwd() error");
            return 1;
        }



        fgets(a, 512, stdin);       //get from the user a string
        a[strlen(a)-1]='\0';

      if(wordcounterf(a)!=0)
          commandscounter++;


        if(strcmp(a,"done")==0) {         //check if the string was  the word exit
            wordcounter++;
            printf("Num of commands: %d \n", commandscounter);
            printf("Total number of words in all commands: %d \n", wordcounter);
            break;

        }

        else if(strcmp(a,"cd")==0){
            printf("command not supported (Yet)\n");
            printf("%d",commandscounter);

        }





         else if(a[0]=='!')  {


            FILE *f = fopen("file.txt", "r");

            if (f == NULL) {
                printf("error while opening this file!");
                return 1;
            }


            int b=strlen(a);
            strncpy(num_line, &a[1],  b- 1);
            num_line[b- 1] = '\0';
            int num = atoi(num_line);

            while (1) {

                fgets(command, 512, f);
             //  printf("%s",command);
                int sus=strlen(command);
               command[sus-1]='\0';



                if (feof(f)) {

                    printf("NOT IN HISTORY\n");
                    fclose(f);
                    current = 1;
                    break;
                }




                else if (current==num)  {

                    if(strcmp(command,"history")==0)
                    {     //check if the string was  the word history
                        fp = fopen("file.txt", "a");
                        if (fp == NULL) //if the file was null
                            exit(0);
                        fprintf(fp, "%s\n", command);   //print into the file all the strings
                        fclose(fp);   // clos the file after we finished
                        wordcounter++;
                        int kak=1;
                        fp = fopen("file.txt", "r");  //open a file

                        while (fgets(str,512, fp) != NULL){  //while the file not finished print all the rows
                            printf("%d: %s",kak,str);
                            kak++;
                        }
                        fclose(fp);   //closing the file



                    }


                       else{
                    find_words_and_save(command);
                   fp = fopen("file.txt", "a");
                    if (f == NULL) //if the file was null
                        exit(0);
                    fprintf(fp, "%s\n", command);   //print into the file all the strings
                    fclose(fp);   // close the file after we finished
                    wordcounter+= wordcounterf(command);
                    current = 1;
                    pid_t id= fork();


                    if (id < 0) {
                        perror("error!");
                        exit(0);


                    }
                    else if (id == 0) { //its the son

                        int status = execvp(argv[0], argv);
                        if (status == -1) {
                            perror("Terminated Incorrectly\n");
                            exit(1);


                        }
                       // printf("%s",command);
                    }
                    else {
                        wait(NULL);
                        int z;
                     for (z = 0; z <= wordcounterf(a); z++) //free to the array
                     free(argv[z]);
                      free(argv);
                        current=1;
                        break;

                    }
                    fclose(f);


                }}




                else
                    current++;

            }

        }





        else if(strcmp(a,"history")==0)
        {     //check if the string was  the word history
            fp = fopen("file.txt", "a");
            if (fp == NULL) //if the file was null
                exit(0);
            fprintf(fp, "%s\n", a);   //print into the file all the strings
            fclose(fp);   // clos the file after we finished
            wordcounter++;
            int kak=1;
            fp = fopen("file.txt", "r");  //open a file

            while (fgets(str,512, fp) != NULL){  //while the file not finished print all the rows
                printf("%d: %s",kak,str);
                kak++;
            }
            fclose(fp);   //closing the file



        }

        else if(a[strlen(a)-1]==' '|| (a[0]==' ')){
            if(wordcounterf(a)==0)
                continue;
            else{
            printf("Error there is a space in the first/last command !\n");
          commandscounter--;
        }
        }


            else
            {
            while (a[i] != '\0')      //while we don't finish the string
            {


                if (a[i] != ' ' && a[i + 1] == '\0') //it is a word
                {
                    wordcounter++;
                    break;
                }

                if (a[i] != ' ' && a[i + 1] == ' ') // it is also a word
                {
                    wordcounter++;
                    i++;
                }

                i++;
            }



            fp = fopen("file.txt", "a");   //open a file for write and append
            if (fp == NULL) //if the file was null
                exit(0);
            if (a[0]== '\0');
            else {
            fprintf(fp, "%s\n", a);   //print into the file all the strings
            fclose(fp);   // clos the file after we finished

        }
               find_words_and_save(a);
                pid=fork();//make a son
                if(pid<0){
                    perror("error!");
                    exit(0);
                }
                else if(pid==0){ //its the son

                    int status= execvp(argv[0], argv);

                    if (status == -1) {
                        perror("Terminated Incorrectly\n");
                        exit(1);

                    }
                }

                else {
                    wait(NULL);
                    int y;
                    for (y = 0; y <= wordcounterf(a); y++) //free to the array
                    free(argv[y]);
                     free(argv);
                }
            }

        i = 0;



    }

}