‏String Parser
‏Authored by Ahmad Abu Sbeih


‏==Description==
‏The program is a String Parser, this progrem read a sentence from the user and then the result will be shown include  how many words was in the  sentence and how many characters in the string , we can use this programm while we dont write the word "exit" because it will be done (finished) and is we write the word"history" the programm will show on the screen all the the string that the user wrote since the first run of the programm 

Program DATABASE
evey sentence we write it into the programm ,  it will be saved in a file with a name"file.txt" if the file wasnt existed then the programm will make and open a new file

‏Functions
‏there is no functions in the programm  except  the main function , in the main we counting the chars and the words 

‏==Program Files==
‏main.c: this file  contains the main programm.

‏==How to compile?==
‏compile: gcc main.c -o main
‏run: ./main

‏==Input==
‏a string  that the length of it is less than 510  characters

‏==Output:== 
‏int ( number of the words in the input
‏int ( number of the characters in the input)
String ( every sentence that the user wrote from the beggining of the programm if he writes"history") 