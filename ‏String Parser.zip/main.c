#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//id: 322786757



int main() {
    char a[510];
    char str[510];
    FILE *fp;
    int i = 0;

    int wordcounter; //count the words
    int lettercounter;//count the letters




    while (1) {  // loop


        lettercounter = 0;
        wordcounter = 0;

        printf("Enter String, or “exit” to end program:\n");
        fgets(a, 510, stdin);       //get from the user a string
        a[strlen(a)-1]='\0';

        if(strcmp(a,"exit")==0) {         //check if the string was  the word exit



            break;

        }
        else if(strcmp(a,"history")==0)
            {     //check if the string was  the word history

            int k=0;
            fp = fopen("file.txt", "r");  //open a file

            while (fgets(str,510, fp) != NULL){  //while the file not finished print all the rows
                printf("%d: %s",k,str);
                k++;
            }
            fclose(fp);   //closing the file



        }

        else
        {
            while (a[i] != '\0')      //while we don't finish the string
            {

                if (a[i] != ' ' && a[i] != '\n')//it is a letter
                {
                    lettercounter++;
                }

                if (a[i] != ' ' && a[i + 1] == '\0') //it is a word
                {
                    wordcounter++;
                    break;
                }

                if (a[i] != ' ' && a[i + 1] == ' ') // it is also a word
                {
                    wordcounter++;
                    i++;
                }

                i++;
            }
            if(wordcounter==0&&lettercounter==0);// if there is no words and letters then don't do anything
            else
            {
                printf("%d words\n", wordcounter);
                printf("%d chars\n", lettercounter);
                fp = fopen("file.txt", "a");   //open a file for write and append
                if (fp == NULL) //if the file was null
                    exit(0);
                fprintf(fp, "%s\n", a);   //print into the file all the strings
                fclose(fp);   // clos the file after we finished
            }



        }
        i = 0;

    }

}