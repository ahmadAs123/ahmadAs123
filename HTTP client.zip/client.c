#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

#define buf_len 1024
int main(int argc,char*argv[]) {
    int num_r=0;
    unsigned char buffer [1024];
    int count=0;
    int r_fun=0;
    int p_fun=0;
    int num_b=0;
    int num;
  //  char* num_p_r;
    char** str1;// double array for r (km 3dd almtgerat b3d alrkm )
    char* str2;// string after p
    char *path_s;// url
    char *port_num;
    char* path;
    char request[240];
    // printf("%d",argc);
    int j=0;
    int i=1;//counter for num of strings in array
    int con_variable;
    int ser;
    struct sockaddr_in serv_addr;
    struct hostent *server_ip;

    if(argc==1)
    {
        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
        exit(0);
    }
    if(argv[i][0]=='-') {
        if (argv[i][1] == 'p') {
            p_fun = 1;
            if (argv[i + 1] == NULL) {
                printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                exit(0);
            }

            num = atoi(argv[i + 1]);
            num_r = num;
            if (num == 0 && strcmp(argv[i + 1] , "0")!=0) {
                printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                exit(0);
            }
            str2 = (char *) malloc(num + 1 * sizeof(char)); // the string after the num of chars that we should take
            if (argv[i + 2] == NULL || num > strlen(argv[i + 2])) {
                printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                exit(0);
            }

            memcpy(str2, argv[i + 2], num);
            str2[num] = '\0';
            if (num < strlen(argv[i + 2])) {
                printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                exit(0);
            }


            if (argv[i + 3][0] == '-') {
                if (argv[i + 3][1] == 'r') {
                    r_fun = 1;
                    str1 = (char **) malloc(atoi(argv[i + 4]) * sizeof(char *));
                    if (argv[i + 4] == NULL) {
                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                        exit(0);
                    }
                    int num1 = atoi(argv[i + 4]);
                    num_r = num1;
                    for (int k = 0; k < num1; j++, k++) {
                        if (argv[i + 5 + k] == NULL) {
                            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                            exit(0);
                        }
                        char *str = (char *) malloc(strlen(argv[i + 5 + k]) + 1 * sizeof(char));
                        strcpy(str, argv[i + 5 + k]);
                        int c_equal = 0;
                        for (int y = 0; y < strlen(argv[i + 5 + k]); y++) {

                            if (argv[i + 5 + k][y] == '=')
                                c_equal++;
                        }
                        if (c_equal == 0) {
                            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                            exit(0);
                        }
                        str1[j] = (char *) malloc((strlen(str) + 1) * sizeof(char));
                        strcpy(str1[j], str);

                    }


                    if (argv[i + 5 + num1] == NULL || strncmp(argv[i + 5 + num1], "http://", 7) != 0) {
                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                        exit(0);
                    }


                    if (strncmp(argv[i + 5 + num1], "http://", 7) == 0) {
                      //  int pth_exist = 0;
                        int port_exist = 0;
                        int u;
                        for (u = 7; u < strlen(argv[i + 5 + num1]); u++) {   // check if theere is a port by :
                            if (argv[i + 5 + num1][u] == ':') {
                                port_exist = 1;
                                break;
                            }
                        }

                        if (port_exist == 1) {// there is port
                            int p = 0;
                            int k;
                            for (k = u + 1; argv[i + 5 + num1][k] != '/'; k++) {
                                p++;
                            }
                            port_num = (char *) malloc(p + 1 * sizeof(char));
                            int oo = 0;
                            while (oo < p) {// copy char by char the web url
                                port_num[oo] = argv[i + 5 + num1][u + 1];
                                oo++;
                                u++;
                            }
                            port_num[p] = '\0';
                            if (argv[i + 5 + num1][k] == '/') {
                                int c_path = 0;
                                int e;
                                for (e = k; e < strlen(argv[i + 5 + num1]); e++) {
                                    c_path++;
                                }
                                path = (char *) malloc(c_path * sizeof(char));
                                int o = 0;
                                while (o < c_path) {// copy char by char the web url
                                    path[o] = argv[i + 5 + num1][k];
                                    o++;
                                    k++;
                                }
                                path[e] = '\0';
                            } else
                                path = "/";
                        } else {
                            port_num = "80";
                            int there_is_slash = 0;
                            for (u = 7; u < strlen(argv[i + 5 + num1]); u++) {   // check if theere is a port by :
                                if (argv[i + 5 + num1][u] == '/') {
                                    there_is_slash = 1;
                                    break;
                                }
                            }

                            if (there_is_slash == 1) {
                                int c_path = 0;
                                int e;
                                for (e = u; e < strlen(argv[i + 5 + num1]); e++) {
                                    c_path++;
                                }
                                path = (char *) malloc(c_path * sizeof(char));
                                int o = 0;
                                while (o < c_path) {// copy char by char the web url
                                    path[o] = argv[i + 5 + num1][u];
                                    o++;
                                    u++;
                                }
                                path[e] = '\0';
                            } else
                                path = "/";
                        }
                        if (port_exist == 1) {
                            for (int l = 7; argv[i + 5 + num1][l] != ':'; l++) {
                                count++;
                            }
                        } else {
                            for (int l = 7; argv[i + 5 + num1][l] != '/'; l++) {
                                count++;
                            }
                        }
                        int y = 0;
                        path_s = (char *) malloc(count + 1 * sizeof(char));

                        while (y < count) {// copy char by char the web url
                            path_s[y] = argv[i + 5 + num1][7 + y];
                            y++;
                        }

                        path_s[count + 1] = '\0';
                    }
                } else {
                    printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                    exit(0);
                }
            }

            else{
                if (argv[i + 3] == NULL || strncmp(argv[i + 3], "http://", 7) != 0) {
                    printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                    exit(0);
                }


                if (strncmp(argv[i + 3], "http://", 7) == 0) {
                //    int pth_exist = 0;
                    int port_exist = 0;
                    int u;
                    for (u = 7; u < strlen(argv[i + 3]); u++) {   // check if theere is a port by :
                        if (argv[i + 3][u] == ':') {
                            port_exist = 1;
                            break;
                        }
                    }

                    if (port_exist == 1) {// there is port
                        int p = 0;
                        int k;
                        for (k = u + 1; k < (strlen(argv[i + 3])) && argv[i + 3][k] != '/'; k++) {
                            p++;
                        }
                        port_num = (char *) malloc(p + 1 * sizeof(char));
                        int oo = 0;
                        while (oo < p) {// copy char by char the web url
                            port_num[oo] = argv[i + 3][u + 1];
                            oo++;
                            u++;
                        }
                        port_num[p] = '\0';
                        if (argv[i + 3][k] == '/') {
                            int c_path = 0;
                            int e;
                            for (e = k; e < strlen(argv[i + 3]); e++) {
                                c_path++;
                            }
                            path = (char *) malloc(c_path * sizeof(char));
                            int o = 0;
                            while (o < c_path) {// copy char by char the web url
                                path[o] = argv[i + 3][k];
                                o++;
                                k++;
                            }
                            path[e] = '\0';
                        } else
                            path = "/";
                    } else {
                        port_num = "80";
                        int there_is_slash = 0;
                        for (u = 7; u < strlen(argv[i + 3]); u++) {   // check if theere is a port by :
                            if (argv[i + 3][u] == '/') {
                                there_is_slash = 1;
                                break;
                            }
                        }

                        if (there_is_slash == 1) {
                            int c_path = 0;
                            int e;
                            for (e = u; e < strlen(argv[i + 3]); e++) {
                                c_path++;
                            }
                            path = (char *) malloc(c_path * sizeof(char));
                            int o = 0;
                            while (o < c_path) {// copy char by char the web url
                                path[o] = argv[i + 3][u];
                                o++;
                                u++;
                            }
                            path[e] = '\0';
                        } else
                            path = "/";
                    }
                    if (port_exist == 1) {
                        for (int l = 7; argv[i + 3][l] != ':'; l++) {
                            count++;
                        }
                    } else {
                        for (int l = 7; argv[i + 3][l] != '/'; l++) {
                            count++;
                        }
                    }
                    int y = 0;
                    path_s = (char *) malloc(count + 1 * sizeof(char));

                    while (y < count) {// copy char by char the web url
                        path_s[y] = argv[i + 3][7 + y];
                        y++;
                    }

                    path_s[count + 1] = '\0';

                }

            }

        }

/*-------------------------------------------------------------------------------------------------------------------------------------------*/
        else  if (argv[i][1] == 'r') {
            r_fun=1;
            str1 = (char **) malloc(atoi(argv[i + 1]) * sizeof(char *));
            if(argv[i+1]==NULL){
                printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                exit(0);
            }
            int num1 = atoi(argv[i + 1]);

            num_r=num1;

            for (int k = 0; k < num1; j++, k++) {
                if(argv[i + 2 + k]==NULL){
                    printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                    exit(0);
                }
                char *str = (char *) malloc(strlen(argv[i + 2 + k]) + 1 * sizeof(char));
                strcpy(str, argv[i + 2 + k]);
                int c_equal=0;
                for(int y=0;y<strlen(argv[i + 2 + k]);y++){

                    if(argv[i+2+k][y]=='=')
                        c_equal++;
                }
                if(c_equal==0){
                    printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                    exit(0);
                }
                str1[j] = (char *) malloc((strlen(str) + 1) * sizeof(char));
                strcpy(str1[j], str);

            }




            if(argv[i+2+num1][0]=='-') {
                if (argv[i+2+num1][1] == 'p') {
                    p_fun = 1;
                    if (argv[i+2+num1 + 1] == NULL) {
                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                        exit(0);
                    }

                    num = atoi(argv[i+2+num1 + 1]);
                    // num_r = num;
                    if (num == 0 && strcmp(argv[i+2+num1 + 1] , "0")!=0) {
                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                        exit(0);
                    }
                    str2 = (char *) malloc(num + 1 * sizeof(char)); // the string after the num of chars that we should take
                    if (argv[i+2+num1 + 2] == NULL || num > strlen(argv[i+2+num1 + 2])) {
                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                        exit(0);
                    }

                    memcpy(str2, argv[i+2+num1 + 2], num);
                    str2[num] = '\0';
                    if (num < strlen(argv[i+2+num1 + 2])) {
                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                        exit(0);
                    }
                    if (argv[i+2+num1 + 3] == NULL || strncmp(argv[i+2+num1 + 3], "http://", 7) != 0) {
                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                        exit(0);
                    }


                    if (strncmp(argv[i+2+num1 + 3], "http://", 7) == 0) {
                     //   int pth_exist = 0;
                        int port_exist = 0;
                        int u;
                        for (u = 7; u < strlen(argv[i+2+num1 + 3]); u++) {   // check if theere is a port by :
                            if (argv[i+2+num1 + 3][u] == ':') {
                                port_exist = 1;
                                break;
                            }
                        }

                        if (port_exist == 1) {// there is port
                            int p = 0;
                            int k;
                            for (k = u + 1; k < (strlen(argv[i+2+num1 + 3])) && argv[i+2+num1 + 3][k] != '/'; k++) {
                                p++;
                            }
                            port_num = (char *) malloc(p + 1 * sizeof(char));
                            int oo = 0;
                            while (oo < p) {// copy char by char the web url
                                port_num[oo] = argv[i+2+num1 + 3][u + 1];
                                oo++;
                                u++;
                            }
                            port_num[p] = '\0';
                            if (argv[i+2+num1 + 3][k] == '/') {
                                int c_path = 0;
                                int e;
                                for (e = k; e < strlen(argv[i+2+num1 + 3]); e++) {
                                    c_path++;
                                }
                                path = (char *) malloc(c_path * sizeof(char));
                                int o = 0;
                                while (o < c_path) {// copy char by char the web url
                                    path[o] = argv[i+2+num1 + 3][k];
                                    o++;
                                    k++;
                                }
                                path[e] = '\0';
                            } else
                                path = "/";
                        } else {
                            port_num = "80";
                            int there_is_slash = 0;
                            for (u = 7; u < strlen(argv[i+2+num1 + 3]); u++) {   // check if theere is a port by :
                                if (argv[i+2+num1 + 3][u] == '/') {
                                    there_is_slash = 1;
                                    break;
                                }
                            }

                            if (there_is_slash == 1) {
                                int c_path = 0;
                                int e;
                                for (e = u; e < strlen(argv[i+2+num1 + 3]); e++) {
                                    c_path++;
                                }
                                path = (char *) malloc(c_path * sizeof(char));
                                int o = 0;
                                while (o < c_path) {// copy char by char the web url
                                    path[o] = argv[i+2+num1 + 3][u];
                                    o++;
                                    u++;
                                }
                                path[e] = '\0';
                            } else
                                path = "/";
                        }
                        if (port_exist == 1) {
                            for (int l = 7; argv[i+2+num1 + 3][l] != ':'; l++) {
                                count++;
                            }
                        } else {
                            for (int l = 7; argv[i+2+num1+ 3][l] != '/'; l++) {
                                count++;
                            }
                        }
                        int y = 0;
                        path_s = (char *) malloc(count + 1 * sizeof(char));

                        while (y < count) {// copy char by char the web url
                            path_s[y] = argv[i+2+num1 + 3][7 + y];
                            y++;
                        }

                        path_s[count + 1] = '\0';

                    }

                }
                else{
                    printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                    exit(0);
                }
            }


            else{
                if(argv[i+2+num1]==NULL||strncmp(argv[i+2+num1],"http://",7)!=0  ){
                    printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                    exit(0);
                }


                if (strncmp(argv[i + 2+num1], "http://", 7) == 0) {
                   // int pth_exist=0;
                    int port_exist=0;
                    int u;
                    for(u=7;u<strlen(argv[i + 2+num1]);u++){   // check if theere is a port by :
                        if(argv[i + 2+num1][u]==':'){
                            port_exist=1;
                            break;
                        }
                    }

                    if(port_exist==1){// there is port
                        int p=0;
                        int k;
                        for ( k = u+1; argv[i + 2+num1][k] != '/'; k++){
                            p++;
                        }
                        port_num=(char *) malloc(p + 1 * sizeof(char));
                        int oo=0;
                        while (oo < p) {// copy char by char the web url
                            port_num[oo] =argv[i + 2+num1][u+1];
                            oo++;
                            u++;
                        }
                        port_num[p] = '\0';
                        if(argv[i + 2+num1][k]=='/'){
                            int c_path=0;
                            int e;
                            for(e=k;e<strlen(argv[i + 2+num1]);e++){
                                c_path++;
                            }
                            path=(char*) malloc(c_path*sizeof(char));
                            int o=0;
                            while (o< c_path) {// copy char by char the web url
                                path[o] = argv[i + 2+num1][k];
                                o++;
                                k++;
                            }
                            path[e] = '\0';
                        }
                        else
                            path="/";
                    }


                    else{
                        port_num="80";
                        int there_is_slash=0;
                        for(u=7;u<strlen(argv[i + 2+num1]);u++){   // check if theere is a port by :
                            if(argv[i + 2+num1][u]=='/'){
                                there_is_slash=1;
                                break;
                            }}

                        if(there_is_slash==1){
                            int c_path=0;
                            int e;
                            for(e=u;e<strlen(argv[i + 2+num1]);e++){
                                c_path++;
                            }
                            path=(char*) malloc(c_path*sizeof(char));
                            int o=0;
                            while (o< c_path) {// copy char by char the web url
                                path[o] = argv[i + 2+num1][u];
                                o++;
                                u++;
                            }
                            path[e] = '\0';
                        }
                        else
                            path="/";
                    }
                    if(port_exist==1){
                        for (int l = 7; argv[i + 2+num1][l] != ':'; l++) {
                            count++;
                        }}
                    else{
                        for (int l = 7; argv[i + 2+num1][l] != '/'; l++) {
                            count++;
                        }
                    }
                    int y = 0;
                    path_s = (char *) malloc(count + 1 * sizeof(char));

                    while (y < count) {// copy char by char the web url
                        path_s[y] = argv[i + 2+num1][7 + y];
                        y++;
                    }

                    path_s[count + 1] = '\0';
                }
            }
        }

        else{
            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
            exit(0);
        }
    }

//------------------------------------------------------------------------------------------------------------------------------------------------

    else{
        if(strncmp(argv[i],"http://",7)==0){

          //  int pth_exist=0;
            int port_exist=0;
            int u;
            for(u=7;u<strlen(argv[i]);u++){   // check if theere is a port by :
                if(argv[i][u]==':'){
                    port_exist=1;
                    break;
                }
            }

            if(port_exist==1){// there is port
                int p=0;
                int k;
                for ( k = u+1; k<strlen(argv[i]) && argv[i][k] != '/'; k++){
                    p++;
                }
                port_num=(char *) malloc(p  * sizeof(char));
                int oo=0;
                while (oo < p) {// copy char by char the web url
                    port_num[oo] = argv[i][u+1];
                    oo++;
                    u++;
                }
                port_num[p] = '\0';

                if(argv[i][k]=='/'){
                    int c_path=0;
                    int e;
                    for(e=k;e<strlen(argv[i]);e++){
                        c_path++;
                    }
                    path=(char*) malloc(c_path*sizeof(char));
                    int o=0;
                    while (o< c_path) {// copy char by char the web url
                        path[o] = argv[i][k];
                        o++;
                        k++;
                    }
                    path[e] = '\0';
                }
                else
                    path="/";
            }


            else{
                port_num="80";
                int there_is_slash=0;
                for(u=7;u<strlen(argv[i]);u++){   // check if theere is a port by :
                    if(argv[i][u]=='/'){
                        there_is_slash=1;
                        break;
                    }}

                if(there_is_slash==1){
                    int c_path=0;
                    int e;
                    for(e=u;e<strlen(argv[i]);e++){
                        c_path++;
                    }
                    path=(char*) malloc(c_path*sizeof(char));
                    int o=0;
                    while (o< c_path) {// copy char by char the web url
                        path[o] = argv[i][u];
                        o++;
                        u++;
                    }
                    path[e] = '\0';
                }
                else
                    path="/";
            }


            if(port_exist==1){
                for(int l=7;argv[i][l]!=':';l++) {
                    count++;
                }}
            else{
                for(int l=7;argv[i][l]!='/';l++) {
                    count++;
                }
            }
            int y=0;
            path_s=(char*)malloc(count+1*sizeof(char));

            while(y<count){// copy char by char the web url
                path_s[y]=argv[i][7+y];
                y++;
            }

            path_s[count+1]='\0';
            i++;



            if(argv[i]==NULL)
                r_fun=1;

            else{

                if(argv[i][0]=='-') {

                    if (argv[i][1] == 'p') {
                        p_fun = 1;
                        int num = atoi(argv[i + 1]);
                        if (num == 0 &&strcmp( argv[i + 1] ,"0")!=0) {
                            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                            exit(0);
                        }

                        str2 = (char *) malloc(
                                num + 1 * sizeof(char)); // the string after the num of chars that we should take
                        if (argv[i + 2] == NULL || num > strlen(argv[i + 2])) {
                            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                            exit(0);
                        }
                        memcpy(str2, argv[i + 2], num);
                        str2[num] = '\0';
                        if (num < strlen(argv[i + 2])) {
                            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                            exit(0);
                        }
                        if (argv[i + 3] == NULL);
                        else{
                            if (argv[i + 3][0] == '-') {
                                if (argv[i + 3][1] == 'r') {
                                    r_fun = 1;
                                    str1 = (char **) malloc(atoi(argv[i + 3 + 1]) * sizeof(char *));
                                    int num1 = atoi(argv[i + 3 + 1]);
                                    num_r = num1;
                                    if (num1 == 0 &&strcmp( argv[i + 3 + 1] ,"0"  )!=0) {
                                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                        exit(0);

                                    }


                                    for (int k = 0; k < num1; j++, k++) {
                                        if (argv[i + 3 + 2 + k] == NULL) {
                                            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                            exit(0);
                                        }
                                        char *str = (char *) malloc(strlen(argv[i + 3 + 2 + k]) + 1 * sizeof(char));
                                        strcpy(str, argv[i + 3 + 2 + k]);
                                        int c_equal = 0;
                                        for (int y = 0; y < strlen(argv[i + 3 + 2 + k]); y++) {

                                            if (argv[i + 3 + 2 + k][y] == '=')
                                                c_equal++;
                                        }
                                        if (c_equal == 0) {
                                            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                            exit(0);
                                        }
                                        str1[j] = (char *) malloc((strlen(str) + 1) * sizeof(char));
                                        strcpy(str1[j], str);

                                    }

                                } else {
                                    printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                    exit(0);
                                }
                            }
                        }
                    }


                    else  if (argv[i][1] == 'r') {
                        r_fun = 1;
                        str1 = (char **) malloc(atoi(argv[i + 1]) * sizeof(char *));
                        int num1 = atoi(argv[i + 1]);
                        num_r = num1;
                        if ( strcmp(argv[i + 1] , "0")!=0 &&  num1 == 0 ) {
                            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                            exit(0);

                        }

                        int k;
                        for (k = 0; k < num1; j++, k++) {
                            if (argv[i + 2 + k] == NULL) {
                                printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                exit(0);
                            }
                            char *str = (char *) malloc(strlen(argv[i + 2 + k]) + 1 * sizeof(char));
                            strcpy(str, argv[i + 2 + k]);
                            int c_equal = 0;
                            for (int y = 0; y < strlen(argv[i + 2 + k]); y++) {

                                if (argv[i + 2 + k][y] == '=')
                                    c_equal++;
                            }
                            if (c_equal == 0) {
                                printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                exit(0);
                            }
                            str1[j] = (char *) malloc((strlen(str) + 1) * sizeof(char));
                            strcpy(str1[j], str);

                        }
                        if (argv[i + 2 + k] == NULL);
                        else{
                            if (argv[i + 2 + k][0] == '-') {
                                if (argv[i + 2 + k][1] == 'p') {
                                    p_fun = 1;
                                    int num = atoi(argv[i + 2 + k + 1]);
                                    if (num == 0 && strcmp(argv[i + 2 + k + 1] ,"0")!=0) {
                                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                        exit(0);
                                    }

                                    str2 = (char *) malloc(num + 1 *
                                                                 sizeof(char)); // the string after the num of chars that we should take
                                    if (argv[i + 2 + k + 2] == NULL || num > strlen(argv[i + 2 + k + 2])) {
                                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                        exit(0);
                                    }
                                    memcpy(str2, argv[i + 2 + k + 2], num);
                                    str2[num] = '\0';
                                    if (num < strlen(argv[i + 2 + k + 2])) {
                                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                        exit(0);
                                    }
                                } else {
                                    printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                                    exit(0);
                                }


                            }
                        }




                    }





                    else{
                        printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                        exit(0);
                    }
                }
                else {
                    printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
                    exit(0);
                }
            }

        }
        else {
            printf("Usage: client [-p n <text>] [-r n < pr1=value1 pr2=value2 …>] <URL>\n");
            exit(0);
        }


    }

    if(p_fun==1&&r_fun==1){
        int num_arg;
        int counter1=0;
        num_arg=counter1;
        char arg[500];
        num_arg=num_r;
        arg[0]='\0';
        request[0]='\0';
        strcat(arg,"?");
        int i;// ther is r in request
        if(num_arg==1){ // there is one argument in the array
            strcat(arg,str1[0]);
            arg[500]='\0';
        }
        else if(num_arg==0);
        else {
            for (i = 0; i < num_arg - 1; i++) {
                strcat(arg, str1[i]);
                strcat(arg, "&");
            }
            strcat(arg, str1[i]);
            arg[500]='\0';
        }
        char len[24];
        sprintf(len, "%ld", strlen(str2));
        strcat(request,"POST ");
        strcat(request,path);
        if(num_r==0);
        else
            strcat(request,arg);
        strcat(request," HTTP/1.0\r\nHOST: ");
        strcat(request,path_s);
        strcat(request,"\r\nContent-length:");
        strcat(request,len);
        strcat(request,"\r\n\r\n");
        strcat(request,str2);
        request[240]='\0';
    }



    else if(r_fun==1){ // r request
        int num_arg;
       // int counter1=0;
        char arg[500];
        //   if(str1[0]==NULL); // there is no arguments in the request

        num_arg=num_r;
        arg[0]='\0';
        request[0]='\0';
        strcat(arg,"?");
        int i;// ther is r in request
        if(num_arg==1){ // there is one argument in the array
            strcat(arg,str1[0]);
            arg[500]='\0';
        }
        else if(num_arg==0);
        else {
            for (i = 0; i < num_arg - 1; i++) {
                strcat(arg, str1[i]);
                strcat(arg, "&");
            }
            strcat(arg, str1[i]);
            arg[500]='\0';
        }
        strcat(request,"GET ");
        strcat(request,path);
        if(num_r==0);
        else
            strcat(request,arg);
        strcat(request," HTTP/1.0\r\nHOST: ");
        strcat(request,path_s);
        strcat(request,"\r\n\r\n");
        // strcat(request,'\0');
        //  request[240]='\0';
    }


    else {

      //  int counter1=0;
     //   int num_arg=counter1;
        char arg[500];
        arg[0]='\0';
        request[0]='\0';
        strcat(arg,"?");
        strcat(arg,str2);
        arg[500]='\0';
        char len[24];
        sprintf(len, "%ld", strlen(str2));
        strcat(request,"POST ");
        strcat(request,path);
        //    strcat(request,arg);
        strcat(request," HTTP/1.0\r\nHOST: ");
        strcat(request,path_s);
        strcat(request,"\r\nContent-length:");
        strcat(request,len);
        strcat(request,"\r\n\r\n");
        strcat(request,str2);
        // strcat(request,'\0');

    }





    printf("HTTP request =\n%s\nLEN = %ld\n", request, strlen(request));
    ser = socket(AF_INET, SOCK_STREAM, 0);
    if(ser<0){
        perror("socket\n");
        exit(EXIT_FAILURE);
    }
    server_ip=gethostbyname(path_s);
    if(server_ip==NULL){
        herror("gethostbyname\n");
    }
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = ((struct in_addr*)(server_ip->h_addr))->s_addr;
    //bcopy((char *)server_ip ->h_addr, (char*)&serv_addr.sin_addr.s_addr, server_ip->h_length);
    serv_addr.sin_port = htons(atoi(port_num));
    con_variable=connect(ser, (struct sockaddr*) &serv_addr, sizeof(serv_addr));
    if(con_variable < 0) {
        perror("connect\n");
        exit(EXIT_FAILURE);
    }
    int counter = write(ser, request, strlen(request));
    if(counter < 0) {
        perror("write\n");
        exit(EXIT_FAILURE);
    }

    while (1){ // loop for reading the ser to the buffer
        int Read_b=read(ser,buffer,buf_len);
        if(Read_b==0){ // we are finished reading
            break;
        }
        num_b+=Read_b;// counting the bytes
        //buffer[Read_b] ='\0';
        write(STDOUT_FILENO, buffer, Read_b);// print the result on the screen
//buffer[0]='\0';

    }
    printf("\n Total received response bytes: %d\n",num_b);
    if(close(ser)<0)// if we cant close the socket
    {
        perror("close\n");
        exit(EXIT_FAILURE);
    }

    return 0;

}
